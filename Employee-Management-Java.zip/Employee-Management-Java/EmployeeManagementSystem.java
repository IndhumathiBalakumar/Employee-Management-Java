import java.io.*;
import java.nio.file.*;
import java.util.*;

class Employee {
    private String empId;
    private String name;
    private String department;
    private double salary;

    public Employee(String empId, String name, String department, double salary) {
        this.empId = String.valueOf(empId);
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    public String getEmpId() { return empId; }
    public String getName() { return name; }
    public String getDepartment() { return department; }
    public double getSalary() { return salary; }

    public void applyRaise(double percentage) {
        double increase = salary * (percentage / 100.0);
        salary += increase;
    }

    public String toJson() {
        return "    {"
                + "\"emp_id\":\"" + escape(empId) + "\","
                + "\"name\":\"" + escape(name) + "\","
                + "\"department\":\"" + escape(department) + "\","
                + "\"salary\":" + salary
                + "}";
    }

    private static String escape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    @Override
    public String toString() {
        return String.format(
                "ID: %s | Name: %-12s | Dept: %-10s | Salary: Rs. %,.2f",
                empId, name, department, salary
        );
    }
}

class EmployeeManager {
    private final String filepath;
    private final List<Employee> employees = new ArrayList<>();

    public EmployeeManager(String filepath) {
        this.filepath = filepath;
        loadFromFile();
    }

    public EmployeeManager() {
        this("employees.json");
    }

    public void loadFromFile() {
        employees.clear();

        Path path = Paths.get(filepath);
        if (!Files.exists(path)) {
            return;
        }

        try {
            String json = Files.readString(path).trim();

            if (json.isEmpty() || json.equals("[]")) {
                return;
            }

            // Simple JSON parser for the structure produced by this program.
            String content = json.substring(1, json.length() - 1).trim();
            if (content.isEmpty()) return;

            List<String> objects = splitObjects(content);

            for (String object : objects) {
                String empId = getJsonString(object, "emp_id");
                String name = getJsonString(object, "name");
                String department = getJsonString(object, "department");
                double salary = Double.parseDouble(getJsonNumber(object, "salary"));

                employees.add(new Employee(empId, name, department, salary));
            }
        } catch (Exception e) {
            System.out.println("\n[Warning] Could not read employees.json. Starting with an empty list.");
            employees.clear();
        }
    }

    private List<String> splitObjects(String content) {
        List<String> result = new ArrayList<>();
        boolean inString = false;
        boolean escaped = false;
        int depth = 0;
        int start = -1;

        for (int i = 0; i < content.length(); i++) {
            char c = content.charAt(i);

            if (escaped) {
                escaped = false;
                continue;
            }

            if (c == '\\' && inString) {
                escaped = true;
                continue;
            }

            if (c == '"') {
                inString = !inString;
            }

            if (!inString) {
                if (c == '{') {
                    if (depth == 0) start = i;
                    depth++;
                } else if (c == '}') {
                    depth--;
                    if (depth == 0 && start >= 0) {
                        result.add(content.substring(start, i + 1));
                        start = -1;
                    }
                }
            }
        }
        return result;
    }

    private String getJsonString(String object, String key) {
        String marker = "\"" + key + "\"";
        int keyPos = object.indexOf(marker);
        if (keyPos < 0) throw new IllegalArgumentException("Missing key: " + key);

        int colon = object.indexOf(':', keyPos + marker.length());
        int firstQuote = object.indexOf('"', colon + 1);
        int i = firstQuote + 1;
        StringBuilder value = new StringBuilder();
        boolean escaped = false;

        while (i < object.length()) {
            char c = object.charAt(i);
            if (escaped) {
                value.append(c);
                escaped = false;
            } else if (c == '\\') {
                escaped = true;
            } else if (c == '"') {
                break;
            } else {
                value.append(c);
            }
            i++;
        }
        return value.toString();
    }

    private String getJsonNumber(String object, String key) {
        String marker = "\"" + key + "\"";
        int keyPos = object.indexOf(marker);
        int colon = object.indexOf(':', keyPos + marker.length());
        int i = colon + 1;

        while (i < object.length() && Character.isWhitespace(object.charAt(i))) i++;

        int start = i;
        while (i < object.length() &&
                (Character.isDigit(object.charAt(i)) ||
                 object.charAt(i) == '.' ||
                 object.charAt(i) == '-')) {
            i++;
        }
        return object.substring(start, i);
    }

    public Employee findEmployee(String empId) {
        for (Employee emp : employees) {
            if (emp.getEmpId().equals(String.valueOf(empId))) {
                return emp;
            }
        }
        return null;
    }

    public void saveToFile() {
        try {
            StringBuilder json = new StringBuilder();
            json.append("[\n");

            for (int i = 0; i < employees.size(); i++) {
                json.append(employees.get(i).toJson());
                if (i < employees.size() - 1) json.append(",");
                json.append("\n");
            }

            json.append("]\n");
            Files.writeString(
                    Paths.get(filepath),
                    json.toString(),
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING
            );
        } catch (IOException e) {
            System.out.println("\n[Error] Could not save employees.json.");
        }
    }

    public boolean addEmployee(String empId, String name, String department, double salary) {
        if (findEmployee(empId) != null) {
            System.out.println("\n[Error] Employee with ID '" + empId + "' already exists!");
            return false;
        }

        if (salary <= 0) {
            System.out.println("\n[Error] Salary must be greater than zero!");
            return false;
        }

        employees.add(new Employee(empId, name, department, salary));
        saveToFile();

        System.out.println("\n[Success] Employee '" + name + "' added successfully!");
        return true;
    }

    public void viewAll() {
        if (employees.isEmpty()) {
            System.out.println("\nNo employees found.");
            return;
        }

        System.out.println("\n" + "=".repeat(70));
        System.out.printf("%35s%n", "ALL EMPLOYEES");
        System.out.println("=".repeat(70));

        for (Employee emp : employees) {
            System.out.println(emp);
        }

        System.out.println("=".repeat(70));
    }

    public void searchByDepartment(String departmentName) {
        List<Employee> matched = new ArrayList<>();

        for (Employee emp : employees) {
            if (emp.getDepartment().trim().equalsIgnoreCase(departmentName.trim())) {
                matched.add(emp);
            }
        }

        if (matched.isEmpty()) {
            System.out.println("\nNo employees found in the '" + departmentName + "' department.");
            return;
        }

        System.out.println("\n" + "=".repeat(70));
        System.out.println("EMPLOYEES IN DEPARTMENT: " + departmentName.toUpperCase());
        System.out.println("=".repeat(70));

        for (Employee emp : matched) {
            System.out.println(emp);
        }

        System.out.println("=".repeat(70));
    }

    public void totalPayroll() {
        double total = 0;

        for (Employee emp : employees) {
            total += emp.getSalary();
        }

        System.out.println("\n" + "-".repeat(45));
        System.out.printf("Total Combined Payroll: Rs. %,.2f%n", total);
        System.out.println("-".repeat(45));
    }

    public boolean giveRaise(String empId, double percentage) {
        Employee emp = findEmployee(empId);

        if (emp == null) {
            System.out.println("\n[Error] Employee with ID '" + empId + "' not found!");
            return false;
        }

        if (percentage <= 0) {
            System.out.println("\n[Error] Raise percentage must be greater than zero!");
            return false;
        }

        double oldSalary = emp.getSalary();
        emp.applyRaise(percentage);
        saveToFile();

        System.out.println("\n" + "-".repeat(50));
        System.out.println("Salary Raise Applied for " + emp.getName()
                + " (ID: " + emp.getEmpId() + ")");
        System.out.printf("Old Salary: Rs. %,.2f%n", oldSalary);
        System.out.printf("New Salary: Rs. %,.2f (+%.2f%%)%n",
                emp.getSalary(), percentage);
        System.out.println("-".repeat(50));

        return true;
    }
}

public class EmployeeManagementSystem {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager();

        while (true) {
            System.out.println("\n========================================");
            System.out.println("       EMPLOYEE MANAGEMENT SYSTEM       ");
            System.out.println("========================================");
            System.out.println("1. Add Employee");
            System.out.println("2. View All Employees");
            System.out.println("3. Search by Department");
            System.out.println("4. Total Payroll");
            System.out.println("5. Give Salary Raise");
            System.out.println("6. Exit");
            System.out.println("========================================");

            System.out.print("Enter your choice (1-6): ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1" -> addEmployee(manager);
                case "2" -> manager.viewAll();
                case "3" -> {
                    System.out.print("Enter Department Name to search: ");
                    String department = scanner.nextLine().trim();
                    manager.searchByDepartment(department);
                }
                case "4" -> manager.totalPayroll();
                case "5" -> giveRaise(manager);
                case "6" -> {
                    System.out.println("\nThank you for using the Employee Management System. Goodbye!\n");
                    scanner.close();
                    return;
                }
                default ->
                        System.out.println("\n[Error] Invalid choice! Please select an option between 1 and 6.");
            }
        }
    }

    private static void addEmployee(EmployeeManager manager) {
        System.out.print("Enter Employee ID: ");
        String empId = scanner.nextLine().trim();

        System.out.print("Enter Employee Name: ");
        String name = scanner.nextLine().trim();

        System.out.print("Enter Department: ");
        String department = scanner.nextLine().trim();

        try {
            System.out.print("Enter Salary: Rs. ");
            double salary = Double.parseDouble(scanner.nextLine().trim());

            manager.addEmployee(empId, name, department, salary);
        } catch (NumberFormatException e) {
            System.out.println("\n[Error] Invalid input! Salary must be a valid numeric value.");
        }
    }

    private static void giveRaise(EmployeeManager manager) {
        System.out.print("Enter Employee ID to receive raise: ");
        String empId = scanner.nextLine().trim();

        try {
            System.out.print("Enter Raise Percentage (e.g., 10 for 10%): ");
            double percentage = Double.parseDouble(scanner.nextLine().trim());

            manager.giveRaise(empId, percentage);
        } catch (NumberFormatException e) {
            System.out.println("\n[Error] Invalid input! Percentage must be a valid numeric value.");
        }
    }
}
