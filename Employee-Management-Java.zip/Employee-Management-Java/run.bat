@echo off
echo ================================
echo  EMPLOYEE MANAGEMENT SYSTEM
echo ================================
echo.
javac EmployeeManagementSystem.java
if errorlevel 1 (
    echo.
    echo Compilation failed.
    pause
    exit /b
)
echo.
java EmployeeManagementSystem
pause
