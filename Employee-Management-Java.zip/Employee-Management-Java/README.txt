# Employee Management System - Python to Java

This project is a Java conversion of the provided Python Employee Management System.

## Features

1. Add Employee
2. View All Employees
3. Search by Department
4. Total Payroll
5. Give Salary Raise
6. Exit
7. Persistent employee data using employees.json

## Requirements

- JDK 17 or newer

Check Java:

    java -version

Check compiler:

    javac -version

## Run

Open Command Prompt/Terminal inside this project folder.

Compile:

    javac EmployeeManagementSystem.java

Run:

    java EmployeeManagementSystem

The program automatically creates/updates:

    employees.json

## Example

Employee ID: 101
Name: Arun
Department: IT
Salary: 30000

Then choose option 5 and enter 10 for a 10% raise.

Old Salary: Rs. 30,000.00
New Salary: Rs. 33,000.00

## Python -> Java mapping

Python class Employee
    -> Java class Employee

Python EmployeeManager
    -> Java EmployeeManager

Python input()
    -> Java Scanner

Python list
    -> Java ArrayList

Python os.path.exists()
    -> Java Files.exists()

Python json.dump()
    -> Java JSON writer

Python json.load()
    -> Java JSON reader

Python f-strings
    -> Java String.format()

No external Java libraries are required.
